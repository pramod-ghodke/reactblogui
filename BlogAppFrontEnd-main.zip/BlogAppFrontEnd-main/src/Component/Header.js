import React from 'react'

const Header = () => {
  return (
       <div>
    <div className='container__header'>
                <p>The</p>
                <h1> Siren </h1>
                
    </div>
    </div>
  )
}

export default Header